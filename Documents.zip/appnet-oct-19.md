# Welcome to Day 1 of Anypoint Platform Architecture: Application Networks
** We Shall start our session at 9:05 AM IST

When login, please check your mic and audio and kindly leave the mics on mute.

Current Role
Location
Exp with Anypoint Platform
SOA and Microservices
Digital Transformation Projects
Expectations from the course


9 am to 5 pm IST
12:30 to 1 : 30 pm

siva-eu-oct-02

# Automation

** Build Automation

	- Mule Maven Plugin

** Test Automation
	- Unit Testing
		- Munit Maven Plugin
	- Functional Testing / Integration Testing
		- BAT CLI / Dataweave

** Publish Automation to Exchange

	- Anypoint CLI
	- Exchange Maven Plugin
	- Platform API

** Deployment Automation
	- Mule Maven Plugin
	- Anypoint CLI
	- Platform API

** Management Automation / Ops Automation
	
	- Anypoint CLI
	- Platform API
	
## My C4E is successful because

** Planning / C4E Establishment Phase
- Membership in C4E Team / org Participation
- Org discovery, Current state of architecture
- Access to systems to participate in API Led connectivity program
- Meetings, Minutes, Decisions made
- Knowledge base / lessons leared
- Reviews
- API Programs / Products defined 
- Standards defined [ devlopment standards, automation, governance, naming conventions, security requirements, compliance]

## API led Connectivity is realised
** Post API Led Connectivity
- Increased reusablity
- Cost reduction	
- Faster product delivery / feature release
- Business outcomes / value
- No of systems connected in real time
- Security, governance, real time monitoring
- Scalable, easy to main, enterprise architecture with visibility


## KPI ?

- No of Assets
- No of Reused Assets
- No of API's in Dev, Test, Prod
- No of connects apps [ automating platform activities eg, Devops, Monitoring etc..]
- No of Systems connected via API
- No of System API, Process API, Experience API
- CI/CD utilization [ build, test and feature - release ]
- No of Discoverable Assets
- No Policy violations and detection of threats and existing vulnarabilities
- No of active users, non active users, api utilization , 


# Note
Communication between Anypoint Management Center and the Mule Agent is authorized by using two way SSL verification. In the following step we are going to create a keystore and request Anypoint Management Center to sign it. Your private key will never leave your machine.


Sending Sign request to Anypoint Management Center

Mule Agent configured successfully

# Onboarding

- Business Groups
- Env
- VPC / Private Spaces
- VPN / Transit Gateway
- DLB / Certificates / Mapping rules

- Teams
- Identity Provider
- Client Provider
- Common Services [ logging, monitoring, ci/cd, alerts ]

https://www.opengroup.org/
https://www.flipkart.com/domain-driven-design/p/itmdytt8z4pnme9c?pid=9780321125217&lid=LSTBOK9780321125217YXKHCL&marketplace=FLIPKART&cmpid=content_book_8003060057_u_8965229628_gmc_pla&tgi=sem,1,G,11214002,u,,,395332127672,,,,c,,,,,,,&ef_id=Cj0KCQjwnbmaBhD-ARIsAGTPcfVK4QlBu_JLNnGhtAOqbr8RIcH8ZBbk3T8LmyMGL8N-Vo4W_QwNPrAaAk3SEALw_wcB:G:s&s_kwcid=AL!739!3!395332127672!!!u!295092701166!&gclid=Cj0KCQjwnbmaBhD-ARIsAGTPcfVK4QlBu_JLNnGhtAOqbr8RIcH8ZBbk3T8LmyMGL8N-Vo4W_QwNPrAaAk3SEALw_wcB&gclsrc=aw.ds
https://en.wikipedia.org/wiki/Domain-driven_design
https://knowledgehub.mulesoft.com/s/
https://www.baeldung.com/inversion-control-and-dependency-injection-in-spring
https://www.enterpriseintegrationpatterns.com/
https://martinfowler.com/articles/products-over-projects.html
https://netflixtechblog.com/
https://status.mulesoft.com/
https://www.enterpriseintegrationpatterns.com/patterns/messaging/IntegrationStylesIntro.html
https://blogs.mulesoft.com/dev-guides/api-connectors-templates/custom-connector-mule-sdk/
https://www.mulesoft.com/platform/cloud-connectors/certified
https://www.mulesoft.com/integration-partner/finder/connector-developer
https://docs.mulesoft.com/api-functional-monitoring/bat-install-task
https://anypoint.mulesoft.com/apitesting/playground/
https://anypoint.mulesoft.com/exchange/portals/anypoint-platform/
https://github.com/mulesoft-catalyst
https://github.com/mulesoft-catalyst/metrics-toolkit
http://anypoint.mulesoft.com/
https://eu1.anypoint.mulesoft.com/home/
https://gov.anypoint.mulesoft.com/
https://aws.amazon.com/ec2/instance-types/
https://aws.amazon.com/eks/getting-started/
https://www.ipaddressguide.com/cidr
https://docs.mulesoft.com/cloudhub-2/ps-gather-setup-info#cidr-block
https://marketplace.fedramp.gov/
https://marketplace.fedramp.gov/#!/product/mulesoft-government-cloud?sort=productName
https://docs.mulesoft.com/private-cloud/3.1/supported-cluster-config
https://docs.mulesoft.com/runtime-manager/cloudhub-networking-guide#regional-services
https://www.mulesoft.com/lp/dl/mule-esb-enterprise
https://docs.mulesoft.com/runtime-fabric/1.7/architecture
https://docs.mulesoft.com/runtime-fabric/2.0/
https://hub.docker.com/
https://www.mulesoft.com/anypoint-pricing
https://docs.mulesoft.com/release-notes/quick-refs/by-date-index
https://anypoint.mulesoft.com/login/
https://anypoint.mulesoft.com/login/signup
https://docs.mulesoft.com/access-management/conf-saml-sso
https://saml-doc.okta.com/SAML_Docs/How-to-Configure-SAML-2.0-for-MuleSoft.html?baseAdmin
https://www.pingidentity.com/en.html
https://drive.google.com/file/d/1wnGcINd7IiM7v8-ZIDRlrQgU94AZw6Em/view?usp=sharing

# Welcome to Day 2 of Anypoint Platform Architecture: Application Networks
** We Shall start our session at 9:05 AM IST

When login, please check your mic and audio and kindly leave the mics on mute.

API Design

- Security Schemas
	client id
	Oauth
	http authen ( username, passwd )
- Health Check Trait
- Protocol 
- Error Codes
- Documentation


Dev Portal

- Experience API
- API Proxy
	never SAPI or PAPI

Reliability
- Transactions
	- Local
	- XA
- Saga
	- Choreographed
	- Orchestrated
	
- reliability pattern

Design Centre
- RAML
- OAS
- Async API

Exchange
- RAML
- OAS
- Async API
- SOAP/WSDL

API Manager
- RAML 
- OAS
- WSDL

# Links

https://github.com/sivadax/mule-examples/tree/master/one-way-two-way-ssl-demo
https://docs.mulesoft.com/api-manager/2.x/mule-oauth-provider-landing-page
https://anypoint.mulesoft.com/exchange/org.mule.templates/api-gateway-oauth2-provider/
https://anypoint.mulesoft.com/exchange/68ef9520-24e9-4cf2-b2f5-620025690913/jwt-validation/
https://istio.io/latest/docs/ops/deployment/architecture/
https://docs.mulesoft.com/service-mesh/1.2/
https://draw.io/
https://nealford.com/katas/
https://automationpanda.com/2017/02/20/the-behavior-driven-three-amigos/
https://github.com/mulesoft-catalyst/common-raml-traits-fragment
https://github.com/mulesoft-catalyst/reusable-raml-fragments
https://github.com/raml-org/raml-spec/blob/master/versions/raml-10/raml-10.md/#user-documentation
https://github.com/raml-org/raml-examples/blob/master/fragments/datatype/general/Email.dataType.raml
https://github.com/raml-org/raml-examples/blob/master/others/banking-api/traits/pageable.raml
https://blogs.mulesoft.com/dev-guides/api-design/api-pagination-patterns/
https://docs.mulesoft.com/design-center/apid-behavioral-headers
https://developer.mozilla.org/en-US/docs/Web/HTTP/Status
https://editor.swagger.io/?docExpansion=none
https://docs.mulesoft.com/anypoint-cli/4.x/anypoint-platform-cli-commands
https://docs.mulesoft.com/anypoint-cli/4.x/install
https://docs.mulesoft.com/api-manager/1.x/accessing-your-api-behind-a-firewall
https://anypoint.mulesoft.com/exchange/portals/mulesoft-training-india/
https://eu1.anypoint.mulesoft.com/exchange/portals/bankofireland/pages/Getting%20Started/
https://anypoint.mulesoft.com/exchange/portals/nz-post-group/
https://datagraph-7339eb19-624f-6d2fdc58-ddb6.us-e1.cloudhub.io/graphql
https://docs.mulesoft.com/datagraph/datagraph-qsg
https://www.nzpost.co.nz/business/ecommerce/developer-resource-centre
https://dev.kone.com/
https://docs.mulesoft.com/mule-runtime/4.4/reliability-patterns
https://docs.mulesoft.com/policies/policies-custom-getting-started#setting-up-a-project-with-the-archetype
https://docs.mulesoft.com/policies/policies-custom-response-example
https://www.nginx.com/blog/introducing-nginx-service-mesh/
https://www.mulesoft.com/lp/reports/mule4-runtime-engine-performance
https://developer.mozilla.org/en-US/docs/Web/HTTP/CORS
https://docs.mulesoft.com/policies/policies-custom-getting-started#:~:text=Custom%20Policies%20are%20policies%20that,Package%20the%20policy.
https://codeshare.io/DZ43gk


# Welcome to Day 3 of Anypoint Platform Architecture: Application Networks
** We Shall start our session at 9:05 AM IST

/v1:


/v2:

HTTP Methods

# Safe

GET, HEAD
Cache / Retry

# Idempotent

Put, Delete, Head, Options, Trace, Get
Retry
DLQ

# Unsafe

Post, Patch
Unique ID / Primary Key
DLQ


# VPC Sizing
3000 x 10 = 30000

#DLB
better performance
Mutual TLS termination
Vanity Domain
Allowlist

appnet-loadbalancer.lb.anypointdns.net
internal-appnet-loadbalancer.lb.anypointdns.net

#Cloudhub 2.0
https://mule-thread-blocker-appnet-gtcehu.rajrd4-1.usa-e1.cloudhub.io


# EDA pub - sub

1 to 1 -> queue [ vm ]
1 to many -> topic [ jms , amqp, kafka ]
1 to selected few [ rabbit mq, kafka ]
few to selected few -> filtering / exchange [ solace , rabbit mq ] - AMQP
random seek -> Kafka

VM
PERSISTANT VM QUEUE [ distributed processing in workers ]
SQS
ANYPOINT MQ 
JMS
AMQP
SOLACE
KAFKA / AZURE HUB

#Links
https://drive.google.com/file/d/1wnGcINd7IiM7v8-ZIDRlrQgU94AZw6Em/view?usp=sharing
https://jwt.io/
https://docs.mulesoft.com/policies/policies-included-spike-control#:~:text=The%20Spike%20Control%20policy%20regulates,the%20limit%20that%20you%20configure.
https://blogs.mulesoft.com/dev-guides/caching-policy-api-performance/
https://docs.mulesoft.com/runtime-fabric/1.7/architecture
https://owasp.org/www-project-top-ten/
https://go.crowdstrike.com/crowdstrike-protection-evolved.html?utm_campaign=brand&utm_content=&utm_medium=sem&utm_source=goog&utm_term=crowdstrike&gclid=Cj0KCQjw48OaBhDWARIsAMd966C0G-yS0o1FkE78vkDopSMWwOjvfyUl1y0cESljspwP_FXGx2rClkIaAtG-EALw_wcB
https://docs.tanium.com/
https://aws.amazon.com/shield/
https://www.akamai.com/products/prolexic-solutions
https://www.microsoft.com/en-us/security/business/endpoint-security/microsoft-defender-business
https://drive.google.com/file/d/1wnGcINd7IiM7v8-ZIDRlrQgU94AZw6Em/view?usp=sharing
https://www.mulesoft.com/integration-partner/program/calendar
https://training.mulesoft.com/course/architecture-healthcare-accelerator
https://blogs.mulesoft.com/api-integration/patterns/advanced-api-patterns-with-raml/
https://stackoverflow.com/questions/56068619/should-i-use-request-id-x-request-id-or-x-correlation-id-in-the-request-header
https://hilton.org.uk/blog/microservices-correlation-id
https://en.wikipedia.org/wiki/HATEOAS
https://mulesofttraining.webex.com/
https://docs.mulesoft.com/apikit/4.x/creating-an-apikit-4-project-with-maven
https://developer.mulesoft.com/download-mule-esb-runtime
https://docs.mulesoft.com/runtime-fabric/2.0/
https://dynamics.microsoft.com/en-in/gp/#sort=relevancy&f:@version=[Microsoft%20Dynamics%20GP]
https://aws.amazon.com/ec2/instance-types/
https://help.mulesoft.com/s/article/How-To-Use-Network-Tools-Application
https://netbeez.net/blog/rfc1918/#:~:text=RFC1918%20Subnets&text=10.0.,255.255%20(10%2F8%20prefix)
https://www.ipaddressguide.com/cidr
https://docs.mulesoft.com/runtime-manager/vpn-about
https://docs.mulesoft.com/cloudhub-2/ps-config-advanced
https://docs.mulesoft.com/runtime-manager/lb-mapping-rules
https://help.mulesoft.com/s/global-search/%40uri#q=dedicated%20load%20balancer&t=SalesforceArticle
https://training.mulesoft.com/oltpublish/cmsres/downloads/MCPA_level1_datasheet.pdf
https://github.com/mulesoft-catalyst/circuit-breaker-policy-mule-4
https://docs.mulesoft.com/dataweave/2.4/dw-mule-functions-p
https://docs.mulesoft.com/dataweave/2.4/dataweave-cookbook-java-methods
https://docs.mulesoft.com/mule-runtime/4.4/about-classloading-isolation
https://www.geeksforgeeks.org/pojo-vs-java-beans/#:~:text=POJO%20stands%20for%20Plain%20Old,re%2Dusability%20of%20a%20program.
https://docs.mulesoft.com/mule-runtime/4.4/about-classloading-isolation
https://docs.mulesoft.com/release-notes/platform/event-driven-api#:~:text=AsyncAPI%20Support%20in%20Anypoint%20Platform&text=You%20can%20create%20an%20AsyncAPI%20specification%20or%20import%20one%20from%20Anypoint%20Exchange.&text=You%20can%20add%20non%2Dmanaged,Designer%20do%20not%20support%20AsyncAPI.
https://github.com/asyncapi/bindings
https://www.cloudamqp.com/
https://howtodoinjava.com/maven/maven-bom-bill-of-materials-dependency/
https://training.mulesoft.com/site/scorm.do?dispatch=scLaunch&pkgId=c217ebd2-8383-11ec-b5a6-0cc47a352292
https://github.com/mulesoft-catalyst/mule-sonarqube-plugin
https://github.com/mulesoft-catalyst/jenkins-automation-demo
https://github.com/mulesoft-consulting
https://principlesofchaos.org/
https://spinnaker.io/
https://github.com/Netflix/chaosmonkey
https://docs.mulesoft.com/monitoring/dashboard-custom-config
https://docs.mulesoft.com/runtime-manager/custom-log-appender
https://github.com/mulesoft-labs/exchange-documentation-samples
